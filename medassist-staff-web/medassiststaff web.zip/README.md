# MedAssist Staff Web
This folder is a separate React/Vite website for authorised healthcare staff. It does NOT add login/registration to the patient calling/mobile flow.

## Run
```bash
cd medassist-staff-web
npm install
npm run seed:mock
npm run dev
```
Open the localhost URL printed by Vite.

Demo login UI defaults: doctor1@medassist.demo / MED-2026. This is prototype-only UI authentication, not production security.

The website reads the same Firebase/Firestore project as the MedAssist app. The seed script creates 10 each of facilities, doctors, patients, appointments and reviews, plus facility incoming case documents.
